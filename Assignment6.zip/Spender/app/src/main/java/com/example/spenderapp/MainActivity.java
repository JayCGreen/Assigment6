package com.example.spenderapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.security.Key;
import java.util.Collections;
import java.util.Date;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    Button add, sub, searchB;
    EditText note, date, amt, desc, sBar, sdate, edate, minamt, maxamt;
    TextView bal;
    float money = 0;
    LinearLayout history;
    TableLayout tab;
    SQLiteDatabase db;
    Cursor curse;
    int entrynum = 0;

    String MyPREFERENCES = "p";
    int histKey= 0;
    String balanceKey = "Bkey";

    String entry = "";

    public void newRow(){
        Log.i("SWW", "waaaaaaa");
        TableRow row = new TableRow(getBaseContext());
        TextView x = new EditText(getBaseContext());
        TextView y = new EditText(getBaseContext());
        TextView z = new EditText(getBaseContext());
        x.setWidth(120);
        y.setWidth(120);
        z.setWidth(120);

        x.setText(curse.getString(1));

        //formatting
        float munny =  curse.getFloat(2);
        if(munny < 0 ){
            y.setText("-$" + (-1*curse.getFloat(2)));
        }
        else{
            y.setText("$" + curse.getFloat(2));
        }
        money += munny;
        z.setText(curse.getString(3));

        row.addView(x, 0);
        row.addView(y, 1);
        row.addView(z, 2);
        row.setGravity(17);
        tab.addView(row, 1);
        curse.move(1);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //sBar = findViewById(R.id.searchBar);

        //search stuff
        minamt = findViewById(R.id.samt);
        maxamt = findViewById(R.id.eamt);
        sdate = findViewById(R.id.sdate);
        edate = findViewById(R.id.edate);

        searchB = findViewById(R.id.searchButt);
        add = findViewById(R.id.add);
        sub = findViewById(R.id.sub);
        date = findViewById(R.id.dateBlock);
        amt = findViewById(R.id.amountBlock);
        desc = findViewById(R.id.descBlock);

        bal = findViewById(R.id.balance);
        tab = findViewById(R.id.table);

        db = openOrCreateDatabase("tester.db", Context.MODE_PRIVATE,null);


        db.execSQL("CREATE TABLE if not EXISTS Transactions  (TransID int NOT NULL PRIMARY KEY, Date DATE, Amount double, Category TEXT)");


        curse = db.rawQuery("Select * from Transactions", null);
        entrynum = curse.getCount();

        curse.moveToFirst();
        Log.i("SWW", "waaaaaaa");
        //load display table
        for (int i = 0; i <entrynum;i++){

            newRow();
        }
        //
        bal.setText("$"+ money);
        //get key
        if(entrynum != 0){
        curse.moveToLast();
        histKey = curse.getInt(0);
        }


        searchB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double minmoney = -Double.MAX_VALUE;
                double maxmoney = Double.MAX_VALUE;
                String startD = "0-0-0";
                String endD = "9999-12-31";

                if (!minamt.getText().toString().isEmpty()){
                    minmoney = Double.parseDouble(minamt.getText().toString());
                }
                if (!maxamt.getText().toString().isEmpty()){
                    maxmoney = Double.parseDouble(maxamt.getText().toString());
                }
                if (!sdate.getText().toString().isEmpty()){
                    startD = sdate.getText().toString();
                }
                if (!edate.getText().toString().isEmpty()){
                    endD = edate.getText().toString();
                }

                minamt.setText(null);
                maxamt.setText(null);
                //date or amount

                curse =  db.rawQuery("Select * from Transactions where Amount Between " + minmoney +" and " +  maxmoney + " and Date Between '" + startD +"' and '" +  endD + "';", null);
                int m = curse.getCount();
                tab.removeViews(1, entrynum);
                curse.moveToFirst();
                for (int i = 0; i <m;i++){

                    newRow();
                }
                //
                entrynum = m;
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String day = date.getText().toString();
                String cat = desc.getText().toString();
                float dollar = Float.parseFloat(amt.getText().toString());
                histKey++;
                Transaction tran = new Transaction(histKey, day, cat, dollar);
                String sql = "INSERT INTO Transactions VALUES " + tran.toSQL();
                Log.i("SQL", sql);
                db.execSQL(sql);
                curse = db.rawQuery("Select * from Transactions", null);
                curse.moveToLast();

                //load table
                newRow();
                //reset the values
                amt.setText(null);
                date.setText(null);
                desc.setText(null);
                date.requestFocus();

                //set new balance
                bal.setText("$"+ money);
            }
        });

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String day = date.getText().toString();
                String cat = desc.getText().toString();
                float dollar = Float.parseFloat(amt.getText().toString());
                histKey++;
                Transaction tran = new Transaction(histKey, day, cat, -dollar);
                String sql = "INSERT INTO Transactions VALUES " + tran.toSQL();
                Log.i("SQL", sql);
                db.execSQL(sql);
                curse = db.rawQuery("Select * from Transactions", null);
                curse.moveToLast();
                //load table
                newRow();
                //reset the values
                amt.setText(null);
                date.setText(null);
                desc.setText(null);
                date.requestFocus();

                //set new balance
                bal.setText("$"+ money);
            }
        });

    }


}
